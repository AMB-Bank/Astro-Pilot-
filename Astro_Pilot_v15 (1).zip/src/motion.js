// Мелкие приятности: состояние шапки, активный пункт меню, подсветка карточек под курсором.
const $$ = (s, c = document) => [...c.querySelectorAll(s)];
const bar = document.querySelector('.topbar');
const onScroll = () => bar?.classList.toggle('is-scrolled', scrollY > 8);
addEventListener('scroll', onScroll, { passive: true }); onScroll();
// Навигация: активный раздел по положению на странице, плавный переход по клику.
const sections = { top: 'home', observations: 'observations', catalog: 'catalog' };
const navLinks = [...document.querySelectorAll('.nav-links a[href^="#"], [data-nav-target]')];
const keyOf = a => (a.dataset.navTarget || a.getAttribute('href').slice(1));
let lock = 0;
function mark(key) {
  navLinks.forEach(a => {
    const on = keyOf(a) === key;
    a.toggleAttribute('data-on', on);
    on ? a.setAttribute('aria-current', 'true') : a.removeAttribute('aria-current');
    a.classList.toggle('is-active', on);
  });
}
const overlay = () => { const s = document.getElementById('catalog-screen'); return s && !s.hidden; };
function spy() {
  if (Date.now() < lock) return;
  if (overlay()) return mark('catalog');
  const line = innerHeight * 0.4; let cur = 'top';
  for (const [key, id] of Object.entries(sections)) { const el = document.getElementById(id); if (el && el.getBoundingClientRect().top <= line) cur = key; }
  mark(cur);
}
addEventListener('scroll', spy, { passive: true }); addEventListener('resize', spy); spy();
document.addEventListener('click', e => {
  const a = e.target.closest('.nav-links a[href^="#"], [data-nav-target]'); if (!a) return;
  const key = keyOf(a); const id = sections[key]; if (!id) return;
  if (key === 'catalog') { mark('catalog'); return; } // полный каталог открывает app.js
  e.preventDefault(); lock = Date.now() + 900; mark(key);
  const wasOpen = overlay();
  if (wasOpen) document.getElementById('catalog-back')?.click(); // сначала закрываем полный каталог
  setTimeout(() => {
    if (key === 'top') scrollTo({ top: 0, behavior: 'smooth' });
    else document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, wasOpen ? 140 : 0);
});
// Состояние в шапке главной повторяет панель наблюдения
document.querySelectorAll('[data-mirror]').forEach(el => {
  const src = document.getElementById(el.dataset.mirror); if (!src) return;
  const copy = () => { el.textContent = src.textContent.trim() || '—'; };
  copy(); new MutationObserver(copy).observe(src, { childList: true, characterData: true, subtree: true });
});
if (matchMedia('(hover:hover)').matches) document.addEventListener('pointermove', e => {
  const c = e.target.closest?.('.object-card'); if (!c) return;
  const r = c.getBoundingClientRect(); c.style.setProperty('--mx', e.clientX - r.left + 'px'); c.style.setProperty('--my', e.clientY - r.top + 'px');
}, { passive: true });

// Телефон: «Навести телескоп» показывает окно трансляции, а не остаётся там, где нажали
document.getElementById('stream-point')?.addEventListener('click', () => {
  if (!matchMedia('(max-width:760px)').matches) return;
  setTimeout(() => (document.getElementById('stream-stage')?.closest('.stream-card') || document.getElementById('stream-stage'))?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
});
