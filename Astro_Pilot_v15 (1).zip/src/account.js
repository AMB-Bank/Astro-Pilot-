// Astro Pilot — аккаунт: регистрация, вход, профиль.
// Работает с /api/*. Если сервер/БД недоступны (например, статический хостинг Netlify),
// автоматически включается локальный профиль: без пароля, хранится только на этом устройстве.
import { firebaseConfig } from './firebase-config.js';
import { createSync } from './sync-core.js';
const $ = (s, c = document) => c.querySelector(s);
const LOCAL_KEY = 'astro-local-profile';
const PERSON = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="8.2" r="3.7"/><path d="M4.6 20.2c.6-3.9 3.4-6 7.4-6s6.8 2.1 7.4 6"/></svg>';
const EYE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/></svg>';

const T = {
  ru: { reg: 'Регистрация', login: 'Вход', guest: 'Войти', title: 'Профиль наблюдателя', sub: 'Сохраняйте избранное и возвращайтесь к наблюдениям с любого устройства.', name: 'Имя пользователя', email: 'Электронная почта', pass: 'Пароль', pass2: 'Повторите пароль', create: 'Создать профиль', enter: 'Войти', out: 'Выйти', close: 'Закрыть', show: 'Показать пароль', busy: 'Подождите…', ok: 'Готово', mismatch: 'Пароли не совпадают', badName: 'От 3 до 32 символов: буквы, цифры, _ . -', badMail: 'Введите корректную почту', badPass: 'Минимум 8 символов', net: 'Нет связи с сервером. Попробуйте ещё раз.', local: 'Сервер аккаунтов не подключён — профиль сохранится только на этом устройстве, без пароля.', localBtn: 'Создать локальный профиль', strength: ['Слабый', 'Средний', 'Хороший', 'Надёжный'], welcome: 'Вы вошли в систему', localTag: 'Локальный профиль', synced: 'Профиль сохранён на сервере' },
  en: { reg: 'Sign up', login: 'Log in', guest: 'Log in', title: 'Observer profile', sub: 'Keep your favourites and return to your observations from any device.', name: 'Username', email: 'Email', pass: 'Password', pass2: 'Repeat password', create: 'Create profile', enter: 'Log in', out: 'Log out', close: 'Close', show: 'Show password', busy: 'Please wait…', ok: 'Done', mismatch: 'Passwords do not match', badName: '3–32 characters: letters, digits, _ . -', badMail: 'Enter a valid email', badPass: 'At least 8 characters', net: 'No connection to the server. Try again.', local: 'The account server is not connected — the profile will be stored on this device only, without a password.', localBtn: 'Create local profile', strength: ['Weak', 'Fair', 'Good', 'Strong'], welcome: 'You are signed in', localTag: 'Local profile', synced: 'Profile is saved on the server' },
};
T.ba = T.ru;
const t = k => (T[localStorage.getItem('astro-language')] || T.ru)[k];

let fb = null;
const FB = 'https://www.gstatic.com/firebasejs/10.14.1/';
async function initFirebase() {
  if (!firebaseConfig?.apiKey) return;
  try {
    const [app, auth, fs] = await Promise.all([import(FB + 'firebase-app.js'), import(FB + 'firebase-auth.js'), import(FB + 'firebase-firestore.js')]);
    const a = app.initializeApp(firebaseConfig);
    if (firebaseConfig.appCheckSiteKey) { // защита от ботов; включается ключом reCAPTCHA в firebase-config.js
      try { const ac = await import(FB + 'firebase-app-check.js'); ac.initializeAppCheck(a, { provider: new ac.ReCaptchaV3Provider(firebaseConfig.appCheckSiteKey), isTokenAutoRefreshEnabled: true }); } catch { /* без App Check */ }
    }
    fb = { ...auth, auth: auth.getAuth(a), fs, db: fs.getFirestore(a) };
  } catch { fb = null; }
}
const FB_ERR = { 'auth/email-already-in-use': 'Эта почта уже зарегистрирована. Попробуйте войти.', 'auth/invalid-credential': 'Неверная почта или пароль.', 'auth/wrong-password': 'Неверная почта или пароль.', 'auth/user-not-found': 'Неверная почта или пароль.', 'auth/too-many-requests': 'Слишком много попыток. Подождите немного.', 'auth/network-request-failed': 'Нет связи с интернетом.', 'auth/weak-password': 'Пароль слишком простой.', 'auth/invalid-email': 'Введите корректную почту.' };
const fbUser = u => ({ uid: u.uid, username: u.displayName || u.email.split('@')[0], email: u.email, verified: u.emailVerified });
const num = k => Number(localStorage.getItem(k) || 0);
const SENT = 'ap-verify-sent', RESET = 'ap-reset-sent', FAIL = 'ap-login-fails';
const left = (k, sec) => Math.max(0, sec - Math.floor((Date.now() - num(k)) / 1000));
// Ограничение попыток входа в браузере — только удобство; настоящую защиту даёт Firebase (auth/too-many-requests) и App Check.
const fails = () => { try { return JSON.parse(localStorage.getItem(FAIL) || '{}'); } catch { return {}; } };
const lockLeft = () => Math.max(0, Math.ceil(((fails().until || 0) - Date.now()) / 1000));
const noteFail = () => { const t = (fails().t || []).filter(x => Date.now() - x < 6e5); t.push(Date.now()); localStorage.setItem(FAIL, JSON.stringify({ t, until: t.length >= 5 ? Date.now() + 6e4 : 0 })); };
let sync = null;
function setupSync() {
  if (!fb || sync) return;
  const { doc, getDoc, setDoc, serverTimestamp } = fb.fs;
  sync = createSync({
    adapter: {
      load: async id => { const s = await getDoc(doc(fb.db, 'users', id)); return s.exists() ? s.data() : null; },
      save: (id, data) => setDoc(doc(fb.db, 'users', id), { ...data, updatedAt: serverTimestamp() }, { merge: true }),
    },
    onFavorites: ids => window.apFavorites?.set(ids),
  });
  addEventListener('ap:favorites', e => sync.change(e.detail));
}
async function syncUser() {
  if (!fb) return; setupSync();
  try { user?.uid ? await sync.login(user.uid, window.apFavorites?.get() || []) : await sync.logout(); } catch { /* облако недоступно — работаем локально */ }
}
let user = null, mode = 'register', serverOk = true, lastFocus = null;

const html = () => `
<div class="acc-backdrop" id="acc-backdrop" hidden>
  <section class="acc-modal" id="acc-modal" role="dialog" aria-modal="true" aria-labelledby="acc-title" tabindex="-1">
    <button class="acc-x" type="button" id="acc-close" aria-label="${t('close')}">×</button>
    <div class="acc-hero"><span class="acc-badge">${PERSON}</span><h2 id="acc-title"></h2><p id="acc-sub"></p></div>
    <div class="acc-seg" id="acc-seg" role="tablist"><button type="button" role="tab" data-mode="register">${t('reg')}</button><button type="button" role="tab" data-mode="login">${t('login')}</button><i aria-hidden="true"></i></div>
    <form class="acc-form" id="acc-form" novalidate>
      <label class="acc-field" data-for="username"><input name="username" placeholder=" " autocomplete="username" maxlength="32"><span>${t('name')}</span><em></em></label>
      <label class="acc-field" data-for="email"><input name="email" type="email" placeholder=" " autocomplete="email" maxlength="191"><span>${t('email')}</span><em></em></label>
      <label class="acc-field" data-for="password"><input name="password" type="password" placeholder=" " maxlength="128"><span>${t('pass')}</span><button type="button" class="acc-eye" aria-label="${t('show')}">${EYE}</button><em></em></label>
      <button type="button" class="acc-link" id="acc-forgot" hidden>Забыли пароль?</button>
      <input class="acc-hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
      <div class="acc-meter" id="acc-meter" hidden><i></i><i></i><i></i><i></i><small></small></div>
      <label class="acc-field" data-for="passwordConfirm"><input name="passwordConfirm" type="password" placeholder=" " autocomplete="new-password" maxlength="128"><span>${t('pass2')}</span><em></em></label>
      <p class="acc-note" id="acc-note" hidden></p>
      <button class="acc-submit" type="submit"><span class="acc-spin" aria-hidden="true"></span><b></b></button>
      <p class="acc-status" id="acc-status" role="status" aria-live="polite"></p>
    </form>
    <div class="acc-profile" id="acc-profile" hidden>
      <span class="acc-badge acc-badge-lg">${PERSON}</span><h3 id="acc-pname"></h3><p id="acc-pmail"></p><span class="acc-tag" id="acc-ptag"></span>
      <div class="acc-verify" id="acc-verify" hidden><p>Почта не подтверждена. Откройте письмо со ссылкой и подтвердите адрес.</p><button type="button" id="acc-resend"></button><button type="button" id="acc-recheck">Я подтвердил(а)</button></div>
      <button type="button" class="acc-out" id="acc-logout">${t('out')}</button>
    </div>
  </section>
</div>`;

function mountTriggers() {
  const top = $('#account-trigger');
  if (top) top.outerHTML = `<button type="button" class="acc-trigger" id="acc-trigger" data-acc-open aria-haspopup="dialog"><span class="acc-ico">${PERSON}</span><span class="acc-trigger-label" id="acc-trigger-label"></span></button>`;
  const mob = $('#mobile-account-avatar')?.closest('button');
  if (mob) { mob.removeAttribute('data-open-account'); mob.setAttribute('data-acc-open', ''); mob.innerHTML = `<span class="acc-ico acc-ico-mobile">${PERSON}</span><small id="acc-mobile-label"></small>`; }
}

function paintTriggers() {
  const label = user ? user.username : t('guest');
  $('#acc-trigger-label') && ($('#acc-trigger-label').textContent = label);
  $('#acc-mobile-label') && ($('#acc-mobile-label').textContent = user ? user.username.slice(0, 9) : t('guest'));
  document.querySelectorAll('.acc-trigger, .acc-ico-mobile').forEach(x => x.classList.toggle('is-in', !!user));
}

function setMode(next) {
  mode = serverOk ? next : 'register';
  const reg = mode === 'register', seg = $('#acc-seg');
  seg.dataset.active = mode === 'reset' ? 'login' : mode; seg.hidden = !serverOk;
  seg.querySelectorAll('button').forEach(b => b.setAttribute('aria-selected', String(b.dataset.mode === mode)));
  $('#acc-title').textContent = mode === 'reset' ? 'Восстановление доступа' : reg ? t('title') : t('login');
  $('#acc-sub').textContent = mode === 'reset' ? 'Укажите почту — отправим ссылку для нового пароля.' : t('sub');
  const f = $('#acc-form');
  f.querySelector('[data-for=username]').hidden = !reg;
  f.querySelector('[data-for=passwordConfirm]').hidden = !reg;
  $('#acc-meter').hidden = !reg;
  f.querySelector('input[name=password]').autocomplete = reg ? 'new-password' : 'current-password';
  f.querySelector('.acc-submit b').textContent = !serverOk && reg ? t('localBtn') : reg ? t('create') : mode === 'reset' ? 'Отправить письмо' : t('enter');
  const note = $('#acc-note');
  note.hidden = serverOk; note.textContent = serverOk ? '' : t('local');
  // в локальном режиме пароль не нужен
  const local = !serverOk;
  ['password', 'passwordConfirm'].forEach(n => { const l = f.querySelector(`[data-for=${n}]`); l.hidden = local || mode === 'reset' || (n === 'passwordConfirm' && !reg); });
  if (local || mode === 'reset') $('#acc-meter').hidden = true;
  $('#acc-forgot').hidden = !(fb && mode === 'login');
  clearErrors();
}

function showView() {
  const profile = $('#acc-profile'), form = $('#acc-form'), seg = $('#acc-seg'), hero = $('.acc-hero');
  const inn = !!user;
  profile.hidden = !inn; form.hidden = inn; seg.hidden = inn; hero.hidden = inn;
  if (inn) {
    $('#acc-pname').textContent = user.username;
    $('#acc-pmail').textContent = user.email || '';
    $('#acc-ptag').textContent = user.local ? t('localTag') : t('synced');
    $('#acc-ptag').dataset.local = user.local ? '1' : '';
    $('#acc-verify').hidden = !(fb && user.verified === false); paintResend();
  } else setMode(mode);
  paintTriggers();
}

function clearErrors() {
  document.querySelectorAll('#acc-form .acc-field').forEach(l => { l.classList.remove('is-bad'); l.querySelector('em').textContent = ''; });
  const s = $('#acc-status'); s.textContent = ''; s.className = 'acc-status';
}
function fieldError(name, msg) {
  const l = document.querySelector(`#acc-form [data-for=${name}]`); if (!l) return;
  l.classList.add('is-bad'); l.querySelector('em').textContent = msg;
}
function status(msg, kind = '') { const s = $('#acc-status'); s.textContent = msg; s.className = 'acc-status ' + kind; }

function strength(p) {
  let n = 0;
  if (p.length >= 8) n++;
  if (p.length >= 12) n++;
  if (/[a-zа-я]/i.test(p) && /\d/.test(p)) n++;
  if (/[^\p{L}\p{N}]/u.test(p) || (/[A-ZА-Я]/.test(p) && /[a-zа-я]/.test(p))) n++;
  return Math.min(n, 4);
}
function paintMeter() {
  const p = $('#acc-form').password.value, n = p ? Math.max(1, strength(p)) : 0, m = $('#acc-meter');
  m.dataset.level = n;
  m.querySelectorAll('i').forEach((i, k) => i.classList.toggle('on', k < n));
  m.querySelector('small').textContent = n ? t('strength')[n - 1] : '';
}

function validate(v) {
  clearErrors();
  if (mode === 'reset') { if (!/^\S+@\S+\.\S+$/.test(v.email)) { fieldError('email', t('badMail')); return false; } return true; }
  let ok = true;
  const bad = (n, m) => { fieldError(n, m); ok = false; };
  const reg = mode === 'register';
  if (reg && !/^[\p{L}\p{N}_.-]{3,32}$/u.test(v.username)) bad('username', t('badName'));
  if (!/^\S+@\S+\.\S+$/.test(v.email)) { if (serverOk || !reg) bad('email', t('badMail')); }
  if (serverOk) {
    if (v.password.length < 8) bad('password', t('badPass'));
    if (reg && v.password !== v.passwordConfirm) bad('passwordConfirm', t('mismatch'));
  }
  return ok;
}

function paintResend() {
  const b = $('#acc-resend'), n = left(SENT, 60);
  b.disabled = n > 0; b.textContent = n > 0 ? `Отправить снова через ${n} с` : 'Отправить письмо ещё раз';
  if (n > 0) setTimeout(paintResend, 1000);
}
const NEUTRAL = 'Если эта почта зарегистрирована, мы отправили письмо со ссылкой.';
async function doReset(v, btn) {
  if (!fb) return status('Восстановление пароля заработает после подключения Firebase.', 'is-error');
  if (!validate(v)) return;
  const n = left(RESET, 60);
  if (n > 0) return status(`Письмо уже отправлено. Повторить можно через ${n} с.`, 'is-error');
  btn.disabled = true; btn.classList.add('is-busy');
  try {
    await fb.sendPasswordResetEmail(fb.auth, v.email);
    localStorage.setItem(RESET, String(Date.now())); status(NEUTRAL, 'is-success');
  } catch (err) {
    if (err.code === 'auth/network-request-failed' || err.code === 'auth/too-many-requests') status(FB_ERR[err.code], 'is-error');
    else { localStorage.setItem(RESET, String(Date.now())); status(NEUTRAL, 'is-success'); } // не раскрываем, есть ли такой аккаунт
  } finally { btn.disabled = false; btn.classList.remove('is-busy'); }
}
async function api(path, options) {
  const r = await fetch(path, { credentials: 'include', ...options });
  const type = r.headers.get('content-type') || '';
  if (!type.includes('json')) throw Object.assign(new Error('no-api'), { noApi: true });
  const data = await r.json().catch(() => ({}));
  return { r, data };
}

async function submit(e) {
  e.preventDefault();
  const f = e.currentTarget, btn = f.querySelector('.acc-submit');
  const v = Object.fromEntries(new FormData(f).entries());
  Object.keys(v).forEach(k => (v[k] = String(v[k]).trim()));
  if (v.website) return; // ловушка для ботов: люди это поле не видят
  delete v.website;
  if (mode === 'reset') return doReset(v, btn);
  if (!serverOk && mode === 'register') {
    if (!/^[\p{L}\p{N}_.-]{3,32}$/u.test(v.username)) return fieldError('username', t('badName')), void 0;
    user = { username: v.username, email: /^\S+@\S+\.\S+$/.test(v.email) ? v.email : '', local: true };
    localStorage.setItem(LOCAL_KEY, JSON.stringify(user));
    showView(); return;
  }
  if (!validate(v)) return;
  if (fb && mode === 'login' && lockLeft() > 0) return status(`Слишком много попыток. Подождите ${lockLeft()} с.`, 'is-error');
  btn.disabled = true; btn.classList.add('is-busy'); status(t('busy'));
  try {
    if (fb) {
      let cred;
      if (mode === 'register') {
        cred = await fb.createUserWithEmailAndPassword(fb.auth, v.email, v.password);
        await fb.updateProfile(cred.user, { displayName: v.username });
      } else cred = await fb.signInWithEmailAndPassword(fb.auth, v.email, v.password);
      if (mode === 'register') { try { await fb.sendEmailVerification(cred.user); localStorage.setItem(SENT, String(Date.now())); } catch { /* можно отправить повторно из профиля */ } }
      else localStorage.removeItem(FAIL);
      user = fbUser(cred.user); f.reset(); paintMeter(); showView(); syncUser(); return;
    }
    const { r, data } = await api(mode === 'register' ? '/api/register' : '/api/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(v),
    });
    if (r.status === 503) throw Object.assign(new Error('down'), { noApi: true });
    if (!r.ok) { status(data.error || t('net'), 'is-error'); return; }
    user = data.user; localStorage.removeItem(LOCAL_KEY); f.reset(); paintMeter(); showView();
  } catch (err) {
    if (err.code?.startsWith('auth/')) {
      if (mode === 'login' && /invalid-credential|wrong-password|user-not-found/.test(err.code)) noteFail(); status(FB_ERR[err.code] || t('net'), 'is-error'); return; }
    if (err.noApi) { serverOk = false; setMode(mode); status('', ''); }
    else status(t('net'), 'is-error');
  } finally { btn.disabled = false; btn.classList.remove('is-busy'); }
}

async function logout() {
  try { if (fb) await fb.signOut(fb.auth); else if (!user?.local) await api('/api/logout', { method: 'POST' }); } catch { /* офлайн */ }
  user = null; localStorage.removeItem(LOCAL_KEY); mode = 'login'; showView(); await syncUser();
}

async function restore() {
  if (fb) { await fb.auth.authStateReady(); user = fb.auth.currentUser ? fbUser(fb.auth.currentUser) : null; serverOk = true; syncUser(); return; }
  try {
    const { r, data } = await api('/api/me');
    if (r.ok && data.authenticated) { user = data.user; return; }
    serverOk = r.status !== 503;
  } catch { serverOk = false; }
  if (!serverOk) { try { user = JSON.parse(localStorage.getItem(LOCAL_KEY) || 'null'); } catch { user = null; } }
}

function open(msg) {
  lastFocus = document.activeElement;
  const b = $('#acc-backdrop'); b.hidden = false;
  if (!user) { setMode(msg ? 'login' : mode); if (msg) $('#acc-sub').textContent = msg; }
  requestAnimationFrame(() => { b.classList.add('is-open'); ($('#acc-form input:not([hidden])') && !user ? $('#acc-form').querySelector('label:not([hidden]) input') : $('#acc-logout'))?.focus(); });
  document.body.classList.add('acc-lock');
}
function close() {
  const b = $('#acc-backdrop'); if (b.hidden) return;
  b.classList.remove('is-open'); document.body.classList.remove('acc-lock');
  setTimeout(() => { b.hidden = true; }, 220); lastFocus?.focus?.();
}

async function init() {
  mountTriggers();
  document.body.insertAdjacentHTML('beforeend', html());
  const modal = $('#acc-modal');
  paintTriggers(); showView();
  document.addEventListener('click', e => { if (e.target.closest('[data-acc-open]')) open(); });
  // избранное только для вошедших
  document.addEventListener('click', e => {
    if (user || !e.target.closest('[data-favorite],#favorites-nav,#favorites-filter')) return;
    e.preventDefault(); e.stopImmediatePropagation(); e.stopPropagation();
    open('Войдите или создайте профиль, чтобы пользоваться избранным.');
  }, true);
  $('#acc-close').onclick = close;
  $('#acc-backdrop').addEventListener('mousedown', e => { if (e.target.id === 'acc-backdrop') close(); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') close();
    if (e.key === 'Tab' && !$('#acc-backdrop').hidden) {
      const items = [...modal.querySelectorAll('button,input')].filter(x => !x.disabled && x.offsetParent);
      if (!items.length) return;
      const first = items[0], last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  $('#acc-seg').addEventListener('click', e => { const b = e.target.closest('button[data-mode]'); if (b) setMode(b.dataset.mode); });
  $('#acc-form').addEventListener('submit', submit);
  $('#acc-form').addEventListener('input', e => { e.target.closest('.acc-field')?.classList.remove('is-bad'); if (e.target.name === 'password') paintMeter(); });
  $('.acc-eye').onclick = e => { const i = e.currentTarget.parentElement.querySelector('input'); const show = i.type === 'password'; i.type = show ? 'text' : 'password'; e.currentTarget.classList.toggle('on', show); };
  $('#acc-logout').onclick = logout;
  $('#acc-forgot').onclick = () => setMode('reset');
  $('#acc-resend').onclick = async () => {
    if (left(SENT, 60) > 0 || !fb?.auth.currentUser) return;
    try { await fb.sendEmailVerification(fb.auth.currentUser); localStorage.setItem(SENT, String(Date.now())); }
    catch (err) { $('#acc-resend').textContent = err.code === 'auth/too-many-requests' ? 'Слишком часто. Попробуйте позже.' : 'Не удалось отправить'; return; }
    paintResend();
  };
  $('#acc-recheck').onclick = async () => {
    try { await fb.auth.currentUser.reload(); user = fbUser(fb.auth.currentUser); showView(); } catch { /* офлайн */ }
  };
  await initFirebase(); await restore(); showView();
}
init();
