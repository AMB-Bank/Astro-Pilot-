// Синхронизация данных пользователя (избранное). Чистая логика без Firebase и DOM —
// хранилище подключается через adapter {load(uid), save(uid, data)}, поэтому её можно тестировать.
export const MAX_FAVORITES = 200;
export const cleanIds = a => [...new Set((Array.isArray(a) ? a : []).filter(x => typeof x === 'string' && /^[a-z0-9_-]{1,40}$/i.test(x)))].slice(0, MAX_FAVORITES);

export function createSync({ adapter, onFavorites, delay = 600, setTimer = setTimeout, clearTimer = clearTimeout }) {
  let uid = null, favs = [], timer = null, dirty = false;
  const write = async () => {
    clearTimer(timer); timer = null;
    if (!uid || !dirty) return;
    dirty = false;
    await adapter.save(uid, { favorites: favs });
  };
  return {
    async login(id, localFavorites = []) {
      await write();                       // не теряем несохранённое от прошлого пользователя
      uid = id; dirty = false;
      const remote = await adapter.load(id);
      if (remote) favs = cleanIds(remote.favorites);
      else { favs = cleanIds(localFavorites); if (favs.length) await adapter.save(id, { favorites: favs }); }
      onFavorites([...favs]);
    },
    change(list) {
      if (!uid) return;                    // гость ничего не пишет в облако
      favs = cleanIds(list); dirty = true;
      clearTimer(timer); timer = setTimer(() => { write().catch(() => { dirty = true; }); }, delay);
    },
    async logout() {
      await write();
      uid = null; favs = []; dirty = false;
      onFavorites([]);                     // приватные данные не остаются в браузере
    },
    flush: write,
    get uid() { return uid; },
  };
}
