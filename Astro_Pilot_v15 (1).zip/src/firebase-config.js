// Конфиг Firebase-проекта astro-pilot-6cbec (веб-ключ не секретный: доступ защищают правила и список доменов).
export const firebaseConfig = {
  apiKey: "AIzaSyBX_OKQZT46Jol-mG7FK3OFh3itlOGEy_g",
  authDomain: "astro-pilot-6cbec.firebaseapp.com",
  projectId: "astro-pilot-6cbec",
  storageBucket: "astro-pilot-6cbec.firebasestorage.app",
  messagingSenderId: "393117578489",
  appId: "1:393117578489:web:771cc7638c5a4f3b495e28",
  // appCheckSiteKey: "",   // ключ reCAPTCHA v3 (Firebase → App Check): защита от автоматических регистраций
};
