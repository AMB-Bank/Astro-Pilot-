// Future Canon EOS 550D pipeline:
// Canon EOS 550D -> Mini-HDMI -> HDMI USB capture card
// -> OBS or camera-service -> WebRTC/HLS video server -> Astro Pilot.
// Keep mode="demo" and streamUrl=null until a real server is available.
export const streamConfig = {
  mode: "demo",
  protocol: "webrtc",
  streamUrl: null,
  fallbackImage: "assets/observatory-demo.jpg",
  signalingUrl: null,
  hlsMimeType: "application/vnd.apple.mpegurl",
  autoplay: true,
  muted: true,
  audio: false,
  metadataUrl: null,
  sourceLabel: "Canon EOS 550D / HDMI capture",
  captureChain: "Canon EOS 550D → Mini-HDMI → capture card → OBS / camera-service",
};
