# Подключение Firebase (регистрация и вход)

1. https://console.firebase.google.com → «Создать проект» (Google Analytics можно отключить).
2. В проекте: значок `</>` (Web) → зарегистрировать приложение → скопировать объект `firebaseConfig`.
3. Конфиг уже вставлен в `src/firebase-config.js`.
4. Build → Authentication → «Get started» → Sign-in method → включить **Email/Password**.
5. Authentication → Settings → Authorized domains → добавить `astropilot.netlify.app` (localhost уже есть).
6. Залить проект на Netlify заново. Кнопка с человечком теперь создаёт настоящие аккаунты.

## Дополнительно (после основной настройки)
1. Firestore Database → Create database (режим production) → вкладка Rules → вставить `firestore.rules` → Publish.
2. Authentication → Settings → включить Email enumeration protection.
3. (Рекомендуется) App Check → зарегистрировать веб-приложение с reCAPTCHA v3 → ключ вставить в `src/firebase-config.js` (`appCheckSiteKey`).
4. Подробности и ограничения: `docs/ARCHITECTURE.md`.
