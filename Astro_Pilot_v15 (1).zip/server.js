import http from 'node:http';
import crypto from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('.', import.meta.url));
const port = Number(process.env.PORT || 3000);
const sessionCookie = 'astro_session';
const sessionAge = 60 * 60 * 24 * 30;
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const db = process.env.DATABASE_URL ? (await import('mysql2/promise')).default.createPool(process.env.DATABASE_URL) : null;
let schemaReady;

async function ensureSchema() {
  if (!db) return false;
  if (!schemaReady) {
    schemaReady = db.execute(`
      CREATE TABLE IF NOT EXISTS astro_users (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(40) NOT NULL UNIQUE,
        email VARCHAR(191) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `).then(() => db.execute(`
      CREATE TABLE IF NOT EXISTS astro_sessions (
        token_hash CHAR(64) NOT NULL PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT astro_sessions_user_fk FOREIGN KEY (user_id) REFERENCES astro_users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `)).then(() => true).catch(error => { schemaReady = null; throw error; });
  }
  return schemaReady;
}
function json(response, status, payload, headers = {}) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  response.end(JSON.stringify(payload));
}
function readJson(request) {
  return new Promise((resolve, reject) => {
    let raw = '';
    request.on('data', chunk => { raw += chunk; if (raw.length > 32_000) reject(new Error('payload-too-large')); });
    request.on('end', () => { try { resolve(JSON.parse(raw || '{}')); } catch { reject(new Error('invalid-json')); } });
    request.on('error', reject);
  });
}
function hashPassword(password) { const salt = crypto.randomBytes(16); const hash = crypto.scryptSync(password, salt, 64); return `${salt.toString('hex')}:${hash.toString('hex')}`; }
function verifyPassword(password, stored) {
  const [saltHex, hashHex] = String(stored).split(':');
  if (!saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, 'hex'), expected.length);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}
function sessionHash(token) { return crypto.createHash('sha256').update(token).digest('hex'); }
function cookies(request) { return Object.fromEntries(String(request.headers.cookie || '').split(';').map(x => x.trim()).filter(Boolean).map(x => { const i = x.indexOf('='); return [x.slice(0, i), decodeURIComponent(x.slice(i + 1))]; })); }
function sessionCookieHeader(token, maxAge = sessionAge, secure = process.env.COOKIE_SECURE !== '0') { return `${sessionCookie}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax;${secure ? ' Secure;' : ''} Max-Age=${maxAge}`; }
async function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  await db.execute('INSERT INTO astro_sessions (token_hash, user_id, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY))', [sessionHash(token), userId]);
  return token;
}
async function currentUser(request) {
  if (!db) return null;
  const token = cookies(request)[sessionCookie];
  if (!token) return null;
  const [rows] = await db.execute('SELECT u.id, u.username, u.email FROM astro_sessions s JOIN astro_users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>NOW() LIMIT 1', [sessionHash(token)]);
  return rows[0] || null;
}
function validation(body) {
  const username = String(body.username || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  const passwordConfirm = body.passwordConfirm == null ? password : String(body.passwordConfirm);
  if (password !== passwordConfirm) return 'Пароли не совпадают.';
  if (!/^[\p{L}\p{N}_.-]{3,32}$/u.test(username)) return 'Имя пользователя: от 3 до 32 символов, без пробелов.';
  if (!/^\S+@\S+\.\S+$/.test(email) || email.length > 191) return 'Введите корректную электронную почту.';
  if (password.length < 8 || password.length > 128) return 'Пароль должен содержать от 8 до 128 символов.';
  return { username, email, password };
}
async function register(request, response) {
  if (request.method !== 'POST') { response.setHeader('Allow', 'POST'); return json(response, 405, { error: 'Метод не поддерживается.' }); }
  if (!db) return json(response, 503, { error: 'Регистрация временно недоступна.' });
  try {
    const data = validation(await readJson(request));
    if (typeof data === 'string') return json(response, 400, { error: data });
    await ensureSchema();
    const [result] = await db.execute('INSERT INTO astro_users (username, email, password_hash) VALUES (?, ?, ?)', [data.username, data.email, hashPassword(data.password)]);
    const token = await createSession(result.insertId);
    return json(response, 201, { registered: true, user: { username: data.username, email: data.email } }, { 'Set-Cookie': sessionCookieHeader(token) });
  } catch (error) {
    if (error?.code === 'ER_DUP_ENTRY') return json(response, 409, { error: 'Такое имя пользователя или почта уже зарегистрированы.' });
    if (error?.message === 'payload-too-large') return json(response, 413, { error: 'Слишком большой запрос.' });
    if (error?.message === 'invalid-json') return json(response, 400, { error: 'Некорректные данные формы.' });
    console.error('Registration error:', error); return json(response, 503, { error: 'Не удалось сохранить регистрацию. Попробуйте позже.' });
  }
}
async function login(request, response) {
  if (request.method !== 'POST') { response.setHeader('Allow', 'POST'); return json(response, 405, { error: 'Метод не поддерживается.' }); }
  if (!db) return json(response, 503, { error: 'Вход временно недоступен.' });
  try {
    const body = await readJson(request); const email = String(body.email || '').trim().toLowerCase(); const password = String(body.password || '');
    await ensureSchema();
    const [rows] = await db.execute('SELECT id, username, email, password_hash FROM astro_users WHERE email=? LIMIT 1', [email]);
    if (!rows[0] || !verifyPassword(password, rows[0].password_hash)) return json(response, 401, { error: 'Неверная почта или пароль.' });
    const token = await createSession(rows[0].id);
    return json(response, 200, { authenticated: true, user: { username: rows[0].username, email: rows[0].email } }, { 'Set-Cookie': sessionCookieHeader(token) });
  } catch (error) { console.error('Login error:', error); return json(response, 503, { error: 'Не удалось выполнить вход. Попробуйте позже.' }); }
}
async function me(request, response) { if (!db) return json(response, 503, { authenticated: false }); if (request.method !== 'GET') return json(response, 405, { error: 'Метод не поддерживается.' }); try { const user = await currentUser(request); return user ? json(response, 200, { authenticated: true, user }) : json(response, 401, { authenticated: false }); } catch (error) { console.error('Session error:', error); return json(response, 503, { error: 'Сессия временно недоступна.' }); } }
async function logout(request, response) { if (request.method !== 'POST') return json(response, 405, { error: 'Метод не поддерживается.' }); if (db) { const token = cookies(request)[sessionCookie]; if (token) await db.execute('DELETE FROM astro_sessions WHERE token_hash=?', [sessionHash(token)]); } return json(response, 200, { authenticated: false }, { 'Set-Cookie': sessionCookieHeader('', 0) }); }

const server = http.createServer(async (request, response) => {
  const requested = request.url?.split('?')[0] || '/';
  if (requested === '/api/register') return register(request, response);
  if (requested === '/api/login') return login(request, response);
  if (requested === '/api/me') return me(request, response);
  if (requested === '/api/logout') return logout(request, response);
  const pathname = requested === '/' ? '/index.html' : requested;
  const target = normalize(join(root, pathname.replace(/^\/+/, '')));
  if (!target.startsWith(root)) { response.writeHead(403); response.end('Forbidden'); return; }
  try { const body = await readFile(target); response.writeHead(200, { 'Content-Type': mime[extname(target)] || 'application/octet-stream', 'Cache-Control': 'no-cache' }); response.end(body); }
  catch { if (!extname(pathname)) { try { const body = await readFile(join(root, 'index.html')); response.writeHead(200, { 'Content-Type': mime['.html'] }); response.end(body); } catch { response.writeHead(500); response.end('Server error'); } } else { response.writeHead(404); response.end('Not found'); } }
});
server.listen(port, '0.0.0.0', () => console.log(`Astro Pilot listening on http://0.0.0.0:${port}`));
