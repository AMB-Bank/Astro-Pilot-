export default {
  logoUrl: "https://dummyimage.com/256x256/070b18/a8f0dc.png&text=SA"
};
