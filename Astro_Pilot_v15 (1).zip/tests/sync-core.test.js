import test from 'node:test';
import assert from 'node:assert/strict';
import { createSync, cleanIds, MAX_FAVORITES } from '../src/sync-core.js';

const memory = () => { const db = new Map(); const log = []; return { db, log,
  async load(uid) { return db.has(uid) ? structuredClone(db.get(uid)) : null; },
  async save(uid, data) { log.push(uid); db.set(uid, structuredClone(data)); } }; };
const make = (adapter) => { const shown = []; const timers = []; 
  const s = createSync({ adapter, onFavorites: x => shown.push(x), setTimer: fn => (timers.push(fn), timers.length), clearTimer: () => {} });
  return { s, shown, run: async () => { while (timers.length) await timers.shift()(); } }; };

test('cleanIds убирает мусор, дубликаты и ограничивает размер', () => {
  assert.deepEqual(cleanIds(['m31', 'm31', 42, '<script>', null, 'moon']), ['m31', 'moon']);
  assert.deepEqual(cleanIds('x'), []);
  assert.equal(cleanIds(Array.from({ length: 500 }, (_, i) => 'o' + i)).length, MAX_FAVORITES);
});
test('первый вход переносит локальное избранное в облако', async () => {
  const a = memory(), { s, shown } = make(a);
  await s.login('u1', ['m31', 'moon']);
  assert.deepEqual(a.db.get('u1').favorites, ['m31', 'moon']);
  assert.deepEqual(shown.at(-1), ['m31', 'moon']);
});
test('если в облаке уже есть данные, локальные не затирают их', async () => {
  const a = memory(); a.db.set('u1', { favorites: ['saturn'] });
  const { s, shown } = make(a);
  await s.login('u1', ['m31']);
  assert.deepEqual(shown.at(-1), ['saturn']);
  assert.deepEqual(a.db.get('u1').favorites, ['saturn']);
});
test('изоляция: данные одного пользователя не попадают другому', async () => {
  const a = memory(), { s, shown, run } = make(a);
  await s.login('alice', []); s.change(['moon', 'm31']); await run();
  await s.logout();
  assert.deepEqual(shown.at(-1), [], 'после выхода интерфейс очищен');
  await s.login('bob', []);                       // у Боба пусто, как и должно быть
  assert.deepEqual(shown.at(-1), []);
  s.change(['saturn']); await run();
  assert.deepEqual(a.db.get('alice').favorites, ['moon', 'm31']);
  assert.deepEqual(a.db.get('bob').favorites, ['saturn']);
});
test('несохранённые изменения записываются владельцу при выходе, а не следующему', async () => {
  const a = memory(), { s } = make(a);
  await s.login('alice', []); s.change(['moon']);
  await s.logout();                               // таймер ещё не сработал
  await s.login('bob', []);
  assert.deepEqual(a.db.get('alice').favorites, ['moon']);
  assert.equal(a.db.has('bob'), false);
});
test('гость ничего не пишет', async () => {
  const a = memory(), { s, run } = make(a);
  s.change(['moon']); await run();
  assert.equal(a.log.length, 0);
});
test('мусорные id из облака отфильтровываются', async () => {
  const a = memory(); a.db.set('u1', { favorites: ['ok', '../x', 7] });
  const { s, shown } = make(a);
  await s.login('u1', []);
  assert.deepEqual(shown.at(-1), ['ok']);
});
