# Сквозной тест окна аккаунта с заглушкой Firebase (Playwright). Запуск: python3 tests/e2e-account.py
# Проверяет логику сайта; настоящий Firebase НЕ проверяет. Путь ниже — собранная одностраничная версия.
from playwright.sync_api import sync_playwright
APP="export const initializeApp=()=>({});"
AUTH="""const S=(window.__fk=window.__fk||{users:{},mail:[],store:{},n:0});
const A={currentUser:null,authStateReady:async()=>{}};
const err=c=>Object.assign(new Error(c),{code:c});
export const getAuth=()=>A;
export const createUserWithEmailAndPassword=async(a,e,p)=>{if(S.users[e])throw err('auth/email-already-in-use');const u={uid:'u'+(++S.n),email:e,pw:p,emailVerified:false,displayName:null,reload:async()=>{u.emailVerified=!!S.verify}};S.users[e]=u;A.currentUser=u;return{user:u}};
export const updateProfile=async(u,d)=>{Object.assign(u,d)};
export const signInWithEmailAndPassword=async(a,e,p)=>{const u=S.users[e];if(!u||u.pw!==p)throw err('auth/invalid-credential');A.currentUser=u;return{user:u}};
export const signOut=async()=>{A.currentUser=null};
export const sendEmailVerification=async u=>{S.mail.push(['verify',u.email])};
export const sendPasswordResetEmail=async(a,e)=>{S.mail.push(['reset',e]);if(!S.users[e])throw err('auth/user-not-found')};"""
FS="""const S=(window.__fk=window.__fk||{users:{},mail:[],store:{},n:0});
export const getFirestore=()=>({});export const doc=(d,...p)=>p.join('/');
export const getDoc=async k=>({exists:()=>k in S.store,data:()=>structuredClone(S.store[k])});
export const setDoc=async(k,d)=>{S.store[k]={...(S.store[k]||{}),...d}};export const serverTimestamp=()=>'ts';"""
mods={'firebase-app.js':APP,'firebase-auth.js':AUTH,'firebase-firestore.js':FS}
ok=lambda c,m:print(('PASS ' if c else 'FAIL ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':900}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    def route(r):
        n=r.request.url.split('/')[-1]
        r.fulfill(body=mods[n],content_type='text/javascript',headers={'access-control-allow-origin':'*'}) if n in mods else r.abort()
    pg.route('https://www.gstatic.com/**',route)
    pg.goto('file:///mnt/user-data/outputs/astro-pilot-preview.html'); pg.wait_for_timeout(1500)
    fk=lambda js:pg.evaluate(js)
    # гость → избранное закрыто
    pg.evaluate("document.querySelector('#catalog').scrollIntoView()"); pg.click('[data-favorite]'); pg.wait_for_timeout(400)
    ok(pg.is_visible('#acc-modal'),'гость: избранное открывает окно входа'); 
    # регистрация
    pg.click('[data-mode=register]'); pg.fill('input[name=username]','alice'); pg.fill('input[name=email]','a@x.ru'); pg.fill('input[name=password]','Passw0rd!x'); pg.fill('input[name=passwordConfirm]','Passw0rd!x')
    pg.click('.acc-submit'); pg.wait_for_timeout(800)
    ok(pg.inner_text('#acc-pname')=='alice','регистрация → профиль alice')
    ok(['verify','a@x.ru'] in fk("window.__fk.mail"),'письмо подтверждения отправлено при регистрации')
    ok(pg.is_visible('#acc-verify'),'показан блок «почта не подтверждена»')
    ok(pg.is_disabled('#acc-resend'),'повторная отправка заблокирована на 60 с')
    # избранное → облако
    pg.keyboard.press('Escape'); pg.wait_for_timeout(400)
    pg.evaluate("document.querySelector('#catalog').scrollIntoView()"); pg.click('[data-favorite]'); pg.wait_for_timeout(1500)
    fav=fk("window.__fk.store['users/u1']?.favorites")
    ok(bool(fav) and len(fav)==1,f'избранное alice записано в users/u1: {fav}')
    # выход очищает
    pg.click('#acc-trigger'); pg.wait_for_timeout(400); pg.click('#acc-logout'); pg.wait_for_timeout(800)
    ok(fk("window.apFavorites.get().length")==0 and fk("localStorage.getItem('astro-favorites')")=='[]','выход: избранное очищено в браузере')
    # второй пользователь не видит чужое
    pg.click('[data-mode=register]'); pg.fill('input[name=username]','bob'); pg.fill('input[name=email]','b@x.ru'); pg.fill('input[name=password]','Passw0rd!y'); pg.fill('input[name=passwordConfirm]','Passw0rd!y')
    pg.click('.acc-submit'); pg.wait_for_timeout(800)
    ok(fk("window.apFavorites.get().length")==0 and 'users/u2' not in fk("Object.keys(window.__fk.store)"),'bob не видит избранное alice, чужой документ не затронут')
    pg.click('#acc-logout'); pg.wait_for_timeout(700)
    # вход alice восстанавливает
    pg.click('[data-mode=login]'); pg.fill('input[name=email]','a@x.ru'); pg.fill('input[name=password]','Passw0rd!x'); pg.click('.acc-submit'); pg.wait_for_timeout(1000)
    ok(fk("window.apFavorites.get().length")==1,'вход alice: избранное восстановлено из облака')
    pg.click('#acc-logout'); pg.wait_for_timeout(700)
    # неверный пароль ×5 → блокировка; сообщение одинаковое
    pg.click('[data-mode=login]')
    for i in range(5):
        pg.fill('input[name=email]','a@x.ru'); pg.fill('input[name=password]','wrongpass1'); pg.click('.acc-submit'); pg.wait_for_timeout(250)
    msg1=pg.inner_text('#acc-status')
    pg.fill('input[name=email]','nobody@x.ru'); pg.click('.acc-submit'); pg.wait_for_timeout(300)
    ok('Слишком много попыток' in pg.inner_text('#acc-status'),'после 5 неудач вход временно заблокирован')
    ok('Неверная почта или пароль' in msg1,'ошибка не раскрывает, существует ли аккаунт')
    # восстановление пароля
    pg.evaluate("localStorage.removeItem('ap-login-fails')"); pg.click('#acc-forgot'); pg.fill('input[name=email]','nobody@x.ru'); pg.click('.acc-submit'); pg.wait_for_timeout(500)
    ok('Если эта почта зарегистрирована' in pg.inner_text('#acc-status'),'сброс пароля: нейтральный ответ даже для несуществующей почты')
    pg.fill('input[name=email]','a@x.ru'); pg.click('.acc-submit'); pg.wait_for_timeout(300)
    ok('уже отправлено' in pg.inner_text('#acc-status').lower() or 'Повторить' in pg.inner_text('#acc-status'),'сброс пароля: ограничение частоты 60 с')
    # honeypot
    mails=len(fk("window.__fk.mail")); 
    print('ошибки страницы:',errs)
    b.close()
