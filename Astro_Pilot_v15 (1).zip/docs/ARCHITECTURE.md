# Astro Pilot — аккаунты, данные, роли, журнал

Реальность на сегодня: вход и регистрация — Firebase Authentication (прямо из браузера), хостинг — Netlify.
Старые `server.js` и MySQL больше не используются (можно удалить).

## 1. Персональное хранилище (Firestore)
```
users/{uid}                    favorites: [id…≤200], settings: {…}, updatedAt
users/{uid}/observations/{id}  журнал (см. п. 6)
auditLog/{id}                  действия админов (пишет только Admin SDK)
```
Доступ — только владелец (`request.auth.uid == uid`). Правила: `firestore.rules`.
В коде: `src/sync-core.js` (логика, 7 тестов) + подключение в `src/account.js`.
Поведение: первый вход аккаунта переносит локальное избранное в облако; если в облаке уже есть данные — они главнее;
выход очищает избранное в браузере; несохранённое при выходе записывается прежнему владельцу, а не следующему.
`settings` в облако пока НЕ синхронизируются (поле зарезервировано в правилах).

## 2–3. Восстановление пароля и подтверждение почты
Письма отправляет Firebase (`sendPasswordResetEmail`, `sendEmailVerification`) — своей почтовой инфраструктуры не нужно.
Шаблоны писем: Console → Authentication → Templates. Ответ сброса пароля всегда нейтральный (не раскрывает, есть ли аккаунт).
Повторная отправка: пауза 60 с в браузере + собственные лимиты Firebase. Подтверждение почты пока ничего не блокирует.

## 4. Защита аккаунта
- Перебор паролей: Firebase возвращает `auth/too-many-requests`; в браузере добавлена пауза после 5 неудач (удобство, не защита).
- Боты: скрытое поле-ловушка + **App Check** (включается ключом reCAPTCHA v3 в `firebase-config.js`, затем «Enforce» в консоли).
- Чтобы нельзя было узнать, есть ли почта в базе: Console → Authentication → Settings → включить **Email enumeration protection**.
- Права: только правила Firestore/Storage. Проверки в клиентском коде — не защита.

## 5. Роли и администратор
Роль `admin` — custom claim, который ставит только `scripts/set-admin.mjs` через Admin SDK. Клиент выдать её себе не может.
Правила читают `request.auth.token.admin`. Панели администратора в интерфейсе **пока нет** — это только основа (роль, правила, журнал).
Аудит: клиентская запись в `auditLog` запрещена правилами. Полноценный аудит действий из интерфейса требует серверной части
(Cloud Functions — на тарифе Blaze) либо выполнения админ-операций скриптами с записью в журнал, как сейчас.

## 6. Будущий журнал наблюдений (`users/{uid}/observations/{id}`)
| поле | тип | примечание |
|---|---|---|
| objectId | string ≤40 | id из каталога, каталог не меняется |
| observedAt | timestamp | дата и время наблюдения |
| equipment | map | `{telescope, mount, camera, eyepiece?}` |
| conditions | map | `{seeing?, cloudCover?, temperatureC?, moon?, source:'open-meteo'\|'manual'}` |
| notes | string ≤2000 | |
| photos | list ≤10 | пути в Storage `users/{uid}/photos/{file}` (до 8 МБ, jpeg/png/webp) |
| createdAt, updatedAt | timestamp | `updatedAt == request.time` |
Правила для фото: `storage.rules`. Внимание: Firebase Storage на новых проектах может требовать тариф Blaze — проверьте в консоли.

## Что проверено и что нет
Проверено: 7 юнит-тестов логики синхронизации (`npm test`); сквозной тест в браузере с **заглушкой** Firebase (`tests/e2e-account.py`).
Не проверено: работа с настоящим Firebase, правила Firestore/Storage (эмулятор недоступен), App Check, реальная доставка писем.
Тестов API для `server.js` нет: он не используется.
