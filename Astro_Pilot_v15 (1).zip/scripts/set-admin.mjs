// Выдать/снять роль администратора. Запускается ТОЛЬКО на вашем компьютере или сервере:
//   npm i firebase-admin --no-save
//   GOOGLE_APPLICATION_CREDENTIALS=./service-account.json node scripts/set-admin.mjs user@example.com [--revoke]
// Ключ service-account.json (Firebase → Project settings → Service accounts) нельзя класть в репозиторий и на сайт.
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

const [email, flag] = process.argv.slice(2);
if (!email) { console.error('Укажите email пользователя'); process.exit(1); }
const revoke = flag === '--revoke';
initializeApp({ credential: applicationDefault() });
const user = await getAuth().getUserByEmail(email);
await getAuth().setCustomUserClaims(user.uid, revoke ? { admin: false } : { admin: true });
await getAuth().revokeRefreshTokens(user.uid); // старые сессии теряют права сразу
await getFirestore().collection('auditLog').add({ action: revoke ? 'admin.revoke' : 'admin.grant', target: user.uid, at: FieldValue.serverTimestamp(), by: 'scripts/set-admin.mjs' });
console.log(`${revoke ? 'Роль снята' : 'Роль выдана'}: ${email} (${user.uid}). Пользователю нужно выйти и войти заново.`);
